#!/bin/bash

# Informazioni dell'utente
nome="Giammarco"
cognome="Fontana"
luogo_di_nascita="Napoli"
data_nascita="25/12/2001"
codice_fiscale="FNTGMR01T25F839E"
indirizzo_di_residenza="Via Roma 123, Scala B, Interno 3, 00100 Roma, RM, Italia"
data_di_scadenza="27/06/2025"
public_key=$(cat user1/keys/keys_user/public_key_u1_user.pem | grep -v 'PUBLIC KEY' | tr -d '\n')

# Cambio directory nella cartella dell'utente
cd user1
mkdir -p ../server_Credenziali_Web/newcerts

touch ../server_Credenziali_Web/index.txt  # Crea il file di database se non esiste
echo '1000' > ../server_Credenziali_Web/serial  # Inizializza il file serial con un numero seriale iniziale


# Generazione di una stringa casuale di hash
openssl rand -out prg_out_data.bin 1024
random_string_hash=$(openssl dgst -sha256 -binary prg_out_data.bin | openssl base64 | tr -d '\n')

# Calcolo dei digest utilizzando la stringa casuale hash per ogni campo
digest_nome=$(echo -n "${random_string_hash}${nome}" | openssl dgst -sha256 | awk '{print $2}')
digest_cognome=$(echo -n "${random_string_hash}${cognome}" | openssl dgst -sha256 | awk '{print $2}')
digest_luogo_di_nascita=$(echo -n "${random_string_hash}${luogo_di_nascita}" | openssl dgst -sha256 | awk '{print $2}')
digest_data_nascita=$(echo -n "${random_string_hash}${data_nascita}" | openssl dgst -sha256 | awk '{print $2}')
digest_codice_fiscale=$(echo -n "${random_string_hash}${codice_fiscale}" | openssl dgst -sha256 | awk '{print $2}')
digest_indirizzo_di_residenza=$(echo -n "${random_string_hash}${indirizzo_di_residenza}" | openssl dgst -sha256 | awk '{print $2}')
digest_data_di_scadenza=$(echo -n "${random_string_hash}${data_di_scadenza}" | openssl dgst -sha256 | awk '{print $2}')
digest_public_key=$(echo -n "${random_string_hash}${public_key}" | openssl dgst -sha256 | awk '{print $2}')

# Combinazione dei digest per formare il digest root
digest_nome_cognome=$(echo -n "${digest_nome}${digest_cognome}" | openssl dgst -sha256 | awk '{print $2}')
digest_luogo_data=$(echo -n "${digest_luogo_di_nascita}${digest_data_nascita}" | openssl dgst -sha256 | awk '{print $2}')
digest_cf_residenza=$(echo -n "${digest_codice_fiscale}${digest_indirizzo_di_residenza}" | openssl dgst -sha256 | awk '{print $2}')
digest_scadenza_pk=$(echo -n "${digest_data_di_scadenza}${digest_public_key}" | openssl dgst -sha256 | awk '{print $2}')

digest_nc_ld=$(echo -n "${digest_nome_cognome}${digest_luogo_data}" | openssl dgst -sha256 | awk '{print $2}')
digest_cr_sp=$(echo -n "${digest_cf_residenza}${digest_scadenza_pk}" | openssl dgst -sha256 | awk '{print $2}')

digest_root=$(echo -n "${digest_nc_ld}${digest_cr_sp}" | openssl dgst -sha256 | awk '{print $2}')

# Calcola il numero di giorni fino alla data di scadenza
current_epoch=$(date +%s)
expiry_epoch=$(date -j -f "%d/%m/%Y" "$data_di_scadenza" +%s)
days_until_expiry=$(( ($expiry_epoch - $current_epoch) / 86400 ))

# Controlla se il numero di giorni è valido
if [ $days_until_expiry -le 0 ]; then
    echo "Errore: il documento è scaduto. Impossibile rilasciare le credenziali."
    exit 1
else
    echo "Giorni fino alla scadenza: $days_until_expiry"
fi

# L'utente si genera la richiesta di certificato
openssl req -new -key keys/keys_user/private_key_u1_user.pem -out user_cert.csr -subj "/C=IT/ST=CAMPANIA/L=AVELLINO/O=GRUPPO007/OU=Verification/CN=www.gruppo007.com"

# Creazione del file di configurazione per la richiesta di certificato
tmp_openssl_config="tmp_openssl.cnf"
cat << EOF > $tmp_openssl_config
[ ca ]
default_ca = CA_default

[ CA_default ]
policy = policy_anything
new_certs_dir = ../server_Credenziali_Web/newcerts
database = ../server_Credenziali_Web/index.txt
serial = ../server_Credenziali_Web/serial
default_md = sha256

[ req ]
default_bits       = 2048
prompt             = no
distinguished_name = req_distinguished_name
req_extensions     = req_ext

[ req_distinguished_name ]
countryName                    = IT
stateOrProvinceName            = CAMPANIA
localityName                   = AVELLINO
organizationName               = GRUPPO007
organizationalUnitName         = Verification
commonName                     = www.gruppo007.com 

[ req_ext ]
subjectAltName = @alt_names

[ policy_anything ]
countryName                    = optional
stateOrProvinceName            = optional
localityName                   = optional
organizationName               = optional
organizationalUnitName         = optional
commonName                     = supplied
emailAddress                   = optional

[ alt_names ]
DNS.1 = DigestNomeCognome:${digest_nome_cognome}
DNS.2 = DigestLuogoDiNascita:${digest_luogo_di_nascita}
DNS.3 = DigestCfResidenza:${digest_cf_residenza}
DNS.4 = DigestScadenza:${digest_data_di_scadenza}
DNS.5 = RandomString:${random_string_hash}
DNS.6 = DataDiNascitaInChiaro:${data_nascita}
DNS.7 = ChiavePubblicaUtente:${public_key}
DNS.8 = DigestRoot:${digest_root}
EOF

# Firma la richiesta di certificato con la CA
openssl ca -in user_cert.csr -out user_cert.crt -days $days_until_expiry -policy policy_anything -config $tmp_openssl_config -extensions req_ext -keyfile ../server_Credenziali_Web/ca/private_key_ca.pem -cert ../server_Credenziali_Web/ca/ca_cert.pem

# Pulizia: rimozione del file di configurazione temporaneo e della CSR
rm $tmp_openssl_config

echo "Certificato con Merkle Tree root e dettagli completi generato e salvato come user_cert.crt"
echo "------------------------------------------"
cd ..
