#!/bin/bash

# Funzione per visualizzare un messaggio di errore e uscire
error_exit() {
    echo "Errore: $1" 1>&2
    echo "Operazione abortita."
    echo "------------------------------------------"
    exit 1
}

# Creazione della struttura delle cartelle per user1
mkdir -p user1/keys/keys_cie || error_exit "Impossibile creare la directory keys_cie"
mkdir -p user1/keys/keys_user || error_exit "Impossibile creare la directory keys_user"
mkdir -p user1/credenziali || error_exit "Impossibile creare la directory credenziali"

# Copia della configurazione specifica per user1
# File che contiene la radice del merkle tree contenete le credenziali e il pin della carta
cp Conf/user1Conf.cnf user1 || error_exit "Impossibile copiare la configurazione per user1"

# Generazione del primo set di parametri ellittici e chiavi per user1 nella cartella keys_user
openssl ecparam -out user1/keys/keys_user/prime256v1_1.pem -name prime256v1 || error_exit "Fallimento nella generazione dei parametri ellittici prime256v1_1"
openssl genpkey -paramfile user1/keys/keys_user/prime256v1_1.pem -out user1/keys/keys_user/private_key_u1_user.pem || error_exit "Fallimento nella generazione della chiave privata per user1"
openssl pkey -in user1/keys/keys_user/private_key_u1_user.pem -pubout -out user1/keys/keys_user/public_key_u1_user.pem || error_exit "Fallimento nella generazione della chiave pubblica per user1"

# Generazione del secondo set di parametri ellittici e chiavi per user1 della cie
openssl ecparam -out user1/keys/keys_cie/prime256v1_2.pem -name prime256v1 || error_exit "Fallimento nella generazione dei parametri ellittici prime256v1_2"
openssl genpkey -paramfile user1/keys/keys_cie/prime256v1_2.pem -out user1/keys/keys_cie/private_key_u1_cie.pem || error_exit "Fallimento nella generazione della chiave privata cie per user1"
openssl pkey -in user1/keys/keys_cie/private_key_u1_cie.pem -pubout -out user1/keys/keys_cie/public_key_u1_cie.pem || error_exit "Fallimento nella generazione della chiave pubblica cie per user1"
