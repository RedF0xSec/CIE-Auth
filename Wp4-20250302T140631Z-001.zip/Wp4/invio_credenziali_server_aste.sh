#!/bin/bash
echo "Redirezione al server d'asta..."
sleep 2
echo "Connesso al server d'asta!"
echo "------------------------------------------"
echo "Invio delle credenziali al server d'asta"

cleanup() {
    echo "Pulizia delle risorse..."
    rm -rf user1 user2 server_Credenziali_Web server_Aste_Web
    echo "Risorse pulite. Connessione terminata."
    echo "------------------------------------------"
}

# Controllo se il certificato esiste nella cartella user1
echo "Verifica esistenza del certificato utente"
if [[ ! -f ./user1/user_cert.crt ]]; then
    echo "Errore: Il certificato user_cert.crt non esiste nella cartella user1."
    cleanup
    exit 1
fi

# Copia del certificato del Merkle Tree nel server d'asta
cp ./user1/user_cert.crt ./server_aste_web/ 

# Controllo del Merkle Tree da parte del server d'asta
if ! bash ./verifica_merkle_tree.sh; then
    echo "Errore durante la verifica del Merkle Tree."
    cleanup
    exit 1
fi