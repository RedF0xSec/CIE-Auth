#!/bin/bash

# Percorso del certificato
cert_path="user1/user_cert.crt"

# L'utente una volta ricevute le credenziali sottoforma di merle tree verifica che il certificato provenga da un'autprità CA
if openssl verify -CAfile server_Credenziali_Web/ca/ca_cert.pem "$cert_path"; then
    echo "Il certificato è stato verificato con successo."
else
    echo "La verifica del certificato è fallita."
    exit 1
fi

# Leggi il contenuto del certificato in una variabile
cert_content=$(openssl x509 -in "$cert_path" -text -noout)

# Estrai i valori dal certificato
data_nascita=$(echo "$cert_content" | grep -o 'DNS:DataDiNascitaInChiaro:[^,]*' | cut -d ':' -f 3- | tr -d ' ')
public_key=$(echo "$cert_content" | grep -o 'DNS:ChiavePubblicaUtente:[^,]*' | cut -d ':' -f 3- | tr -d ' ')
random_string=$(echo "$cert_content" | grep -o 'DNS:RandomString:[^,]*' | cut -d ':' -f 3- | tr -d ' ')
digest_nome_cognome=$(echo "$cert_content" | grep -o 'DNS:DigestNomeCognome:[^,]*' | cut -d ':' -f 3- | tr -d ' ')
digest_luogo_di_nascita=$(echo "$cert_content" | grep -o 'DNS:DigestLuogoDiNascita:[^,]*' | cut -d ':' -f 3- | tr -d ' ')
digest_cf_residenza=$(echo "$cert_content" | grep -o 'DNS:DigestCfResidenza:[^,]*' | cut -d ':' -f 3- | tr -d ' ')
digest_scadenza=$(echo "$cert_content" | grep -o 'DNS:DigestScadenza:[^,]*' | cut -d ':' -f 3- | tr -d ' ')

# Verifica che i valori non siano vuoti
if [[ -z "$data_nascita" || -z "$public_key" || -z "$random_string" || -z "$digest_nome_cognome" || -z "$digest_luogo_di_nascita" || -z "$digest_cf_residenza" || -z "$digest_scadenza" ]]; then
    echo "Errore: Uno o più valori estratti dal certificato sono vuoti."
    exit 1
fi

# Calcola gli SHA-256 della data di nascita e della public key concatenata con la random string
digest_data_nascita=$(echo -n "${random_string}${data_nascita}" | openssl dgst -sha256 | awk '{print $2}')
digest_public_key=$(echo -n "${random_string}${public_key}" | openssl dgst -sha256 | awk '{print $2}')

# Calcola gli hash intermedi
digest_luogo_data=$(echo -n "${digest_luogo_di_nascita}${digest_data_nascita}" | openssl dgst -sha256 | awk '{print $2}')
digest_scadenza_pk=$(echo -n "${digest_scadenza}${digest_public_key}" | openssl dgst -sha256 | awk '{print $2}')

digest_nc_ld=$(echo -n "${digest_nome_cognome}${digest_luogo_data}" | openssl dgst -sha256 | awk '{print $2}')
digest_cr_sp=$(echo -n "${digest_cf_residenza}${digest_scadenza_pk}" | openssl dgst -sha256 | awk '{print $2}')

# Calcola la radice del Merkle Tree
calculated_merkle_root=$(echo -n "${digest_nc_ld}${digest_cr_sp}" | openssl dgst -sha256 | awk '{print $2}')

# Estrai la radice del Merkle Tree dal certificato
merkle_root=$(echo "$cert_content" | grep -o 'DNS:DigestRoot:[^,]*' | cut -d ':' -f 3- | tr -d ' ')

# Verifica che la radice del Merkle Tree non sia vuota
if [[ -z "$merkle_root" ]]; then
    echo "Errore: La radice del Merkle Tree estratta dal certificato è vuota."
    exit 1
fi

# Confronta la radice del Merkle Tree estratta con quella calcolata
if [ "$merkle_root" == "$calculated_merkle_root" ]; then
    echo "La radice del Merkle Tree è stata verificata con successo."
    echo "------------------------------------------"
    exit 0
else
    echo "La verifica della radice del Merkle Tree è fallita."
    exit 1
fi