#!/bin/bash

cleanup() {
    echo "Pulizia delle risorse..."
    rm -rf user1 user2 server_Credenziali_Web server_Aste_Web
    echo "Risorse pulite. Connessione terminata."
    echo "------------------------------------------"
}

# Simulazione della connessione al server d'aste
echo "Connessione al server d'aste..."
sleep 2  # Simula il tempo di attesa della connessione
echo "Connesso!"
echo "------------------------------------------"

# Chiedi all'utente se vuole accedere al sito
read -p "Vuoi accedere al sito? (y/n): " access_response

if [[ $access_response == "y" ]]; then
    # Chiedi se l'utente possiede già le credenziali
    read -p "Possiedi già le credenziali? (y/n): " cred_response
    echo "------------------------------------------"
    if [[ $cred_response == "n" ]]; then

        # Creazione delle cartelle dell'utente e dei due server
        if ! bash ./start_user.sh; then
            echo "Errore durante l'avvio degli utenti."
            cleanup
            exit 1
        fi
        if ! bash ./start_servers_web.sh; then
            echo "Errore durante l'avvio dei server web."
            cleanup
            exit 1
        fi

        echo "Redirezione al server delle credenziali..."
        sleep 2
        echo "Connesso al server delle credenziali!"
        echo "------------------------------------------"
        # Protocollo di Schnorr tra utente e server delle credenziali
        if ! bash ./schnorr_proof_sc.sh; then
            echo "Errore durante il protocollo di Schnorr."
            cleanup
            exit 1
        fi
        # Richiesta delle credenziali da parte dell'utente
        if ! bash ./richiesta_credenziali.sh; then
            echo "Errore durante la richiesta di credenziali."
            cleanup
            exit 1
        fi
        # L'utente manda le credenzali al server d'asta
        if ! bash ./invio_credenziali_server_aste.sh; then
            echo "Errore durante l'invio delle credenziali al server delle aste."
            cleanup
            exit 1
        fi 
        # Verifica dell'intetà dell'utente da parte del server d'asta 
        if ! bash ./verifica_identità_utente.sh; then
            echo "Errore durante la verifica dell'identità dell'utente."
            cleanup
            exit 1
        fi 
    # nel caso l'utente ha già le credenziali
    elif [[ $cred_response == "y" ]]; then
        echo "Accesso in corso con le credenziali esistenti..."
        if ! bash ./invio_credenziali_server_aste.sh; then
            echo "Errore durante l'invio delle credenziali al server delle aste."
            cleanup
            exit 1
        fi 
        if ! bash ./verifica_identità_utente.sh; then
            echo "Errore durante la verifica dell'identità dell'utente."
            cleanup
            exit 1
        fi 
    else
        echo "Risposta non valida. Si prega di rispondere con 'y' o 'n'."
        cleanup
        exit 1
    fi
# Se l'utente non vuole accedere al sito
elif [[ $access_response == "n" ]]; then
    echo "Accesso annullato dall'utente. Se non volevi accedere perchè hai avviato lo script? :("
    cleanup
    exit 0
else
    echo "Risposta non valida. Si prega di rispondere con 'y' o 'n'."
    cleanup
    exit 1
fi
