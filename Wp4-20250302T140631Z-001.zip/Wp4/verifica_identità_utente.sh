#!/bin/bash
echo "Verifica credenziali..."

# Nome del certificato
CERT_FILE="./user1/user_cert.crt"

# Controlla se il file del certificato esiste
echo "Verifica esistenza del certificato utente"
if [ ! -f "$CERT_FILE" ]; then
  echo "Il file $CERT_FILE non esiste nella cartella corrente."
  exit 1
fi

# Legge il contenuto del certificato in una variabile
cert_content=$(openssl x509 -in "$CERT_FILE" -text -noout)

# Estrai il campo DNS.6 (Data di nascita in chiaro)
DNS6=$(echo "$cert_content" | grep -o 'DNS:DataDiNascitaInChiaro:[^,]*' | cut -d ':' -f 3-)

# Estrai il campo DNS.7 (Chiave pubblica utente)
DNS7=$(echo "$cert_content" | grep -o 'DNS:ChiavePubblicaUtente:[^,]*' | cut -d ':' -f 3-)

# Controlla se il campo DNS.6 è stato trovato
if [ -z "$DNS6" ]; then
  echo "Il campo DNS.6 non è stato trovato nel certificato."
  exit 1
fi

# Controlla se il campo DNS.7 è stato trovato
if [ -z "$DNS7" ]; then
  echo "Il campo DNS.7 non è stato trovato nel certificato."
  exit 1
fi

# Inizio del protocollo di Schnorr
echo "Inizio protocollo di Schnorr.."
sleep 2

# Verifica che la directory user1 e il file del messaggio esistano
if [ ! -d "user1" ]; then
  echo "La directory user1 non esiste."
  exit 1
fi

# Creazione del messaggio da parte del server d'asta far firmare all'utente
echo "user1" > user1/test2.txt || { echo "Errore nella creazione del messaggio!"; exit 1; }
openssl dgst -sha256 -sign user1/keys/keys_user/private_key_u1_user.pem -out user1/signature2.bin user1/test2.txt || { echo "Errore nella firma del messaggio!"; exit 1; }

# Controlli per la copia dei file verso il server
mkdir -p server_Aste_Web
cp user1/test2.txt server_Aste_Web && cp user1/signature2.bin server_Aste_Web || { echo "Errore nella copia del messaggio o della firma!"; exit 1; }

# Verifica della firma dal server delle credenziali
echo "serverWeb: verifico chiave user1..."

if echo -n "$DNS7" | base64 -d > /tmp/public_key.pem; then
    if openssl dgst -sha256 -verify /tmp/public_key.pem -signature server_Aste_Web/signature2.bin server_Aste_Web/test2.txt; then
        echo "Verifica completata con successo. Protocollo di Schnorr terminato!"
    else
        echo "Verifica fallita! Protocollo di Schnorr interrotto."
        exit 1
    fi
else
    echo "Errore nella conversione della chiave pubblica."
    exit 1
fi

echo "------------------------------------------"

# Controllo dell'età dell'utente
birth_year=$(echo "$DNS6" | awk -F'/' '{print $3}')
birth_month=$(echo "$DNS6" | awk -F'/' '{print $2}' | sed 's/^0*//')  # Rimuove gli zeri iniziali
birth_day=$(echo "$DNS6" | awk -F'/' '{print $1}' | sed 's/^0*//')  # Rimuove gli zeri iniziali

current_year=$(date +%Y)
current_month=$(date +%m | sed 's/^0*//')  # Rimuove gli zeri iniziali
current_day=$(date +%d | sed 's/^0*//')  # Rimuove gli zeri iniziali

age=$((current_year - birth_year))

if (( current_month < birth_month || (current_month == birth_month && current_day < birth_day) )); then
  age=$((age - 1))
fi

# Verifica se l'utente è maggiorenne
if [ "$age" -lt 18 ]; then
  echo "L'utente non è maggiorenne. Ha $age anni. Accesso negato"
  exit 1
fi

echo "L'utente è maggiorenne. Ha $age anni. Accesso consentito!"
