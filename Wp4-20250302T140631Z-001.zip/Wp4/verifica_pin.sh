#!/bin/bash

# Simula l'avvicinamento della carta al sensore NFC
echo "Avvicinare la carta al sensore NFC..."
sleep 2  # Simula un piccolo ritardo mentre la carta è letta dal sensore

# Chiedi all'utente di inserire il PIN
echo "Inserire il PIN per procedere:"
read -s pin  # L'opzione -s rende il PIN invisibile durante la digitazione per la privacy

# Verifica se il PIN è corretto
PIN_CORRETTO="0123456789"

if [[ "$pin" == "$PIN_CORRETTO" ]]; then
    echo "PIN corretto. Procedura autorizzata."
    exit 0 
else
    echo "PIN incorretto. Accesso negato."
    echo "Connessione terminata."
    exit 1
fi
