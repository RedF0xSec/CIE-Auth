#!/bin/bash

# Funzione per gestire gli errori durante l'esecuzione del comando
error_exit() {
    echo "Errore: $1" 1>&2
    echo "Operazione abortita."
    exit 1
}

# Creazione delle directory per i server
mkdir server_Aste_Web || error_exit "Impossibile creare la directory server_Aste_Web"
mkdir server_Credenziali_Web || error_exit "Impossibile creare la directory server_Credenziali_Web"

# Creazione di una directory per la CA
mkdir -p server_Credenziali_Web/ca

# Generazione della chiave privata per la CA
openssl genpkey -algorithm EC -out server_Credenziali_Web/ca/private_key_ca.pem -pkeyopt ec_paramgen_curve:prime256v1

# Creazione del certificato autofirmato per la CA
openssl req -new -x509 -key server_Credenziali_Web/ca/private_key_ca.pem -out server_Credenziali_Web/ca/ca_cert.pem -days 365 -subj "/C=IT/ST=CAMPANIA/L=SALERNO/O=MDI/OU=CA/CN=www.interno.gov.it"
