Per avviare la simulazione, è necessario, tramite terminale:
•	Spostarsi nella cartella Wp4
•	Eseguire la simulazione mediante il comando: bash ./simulazione.sh
•	Seguire le istruzioni riportate a video
