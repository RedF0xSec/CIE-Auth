#!/bin/bash

cleanup() {
    echo "Pulizia delle risorse..."
    rm -rf user1 user2 server_Credenziali_Web server_Aste_Web
    echo "Risorse pulite. Connessione terminata."
    echo "------------------------------------------"
}

# Chiedi all'utente se desidera ricevere le credenziali dal server delle credenziali
read -p "Vuoi ottenere le credenziali dal server delle credenziali? (y/n): " response
echo "------------------------------------------"
if [[ $response == "y" ]]; then
    # Naviga nella directory dell'utente
    cd user1 || { echo "Errore: directory user1 non trovata."; exit 1; }
    
    # Genera una richiesta di certificato firmata
    echo "Sto mandando la richiesta per ottenere le credenziali..."
    sleep 2
    echo "Richiesta credenziali" > richiesta_credenziali.txt

    # Copio i file di interesse da verificare nella cartella del server delle credenziali
    cp richiesta_credenziali.txt ../server_Credenziali_Web && cp keys/keys_user/public_key_u1_user.pem ../server_Credenziali_Web || { echo "Errore nella copia dei file."; exit 1; }
    cd ../server_Credenziali_Web || { echo "Errore: directory server_Credenziali_Web non trovata."; exit 1; }
    
    echo "Richiesta ricevuta dal server delle credenziali. Puoi andare avanti."
    echo "------------------------------------------"
    # Il server delle credenziali genera il modulo per il rilascio delle credenziali all'utente
    echo "Modulo da firmare" > modulo.txt
    
    # L'utente inserisce il pin e la carta lo verifica 
    bash ../verifica_pin.sh || { echo "Verifica PIN fallita. Operazione abortita."; exit 1; }
    
    # L'utente firma il modulo di rilascio
    openssl dgst -sha256 -sign ../user1/keys/keys_cie/private_key_u1_cie.pem -out modulo_firmato.bin modulo.txt || { echo "Errore nella firma del modulo."; exit 1; }
    
    # Il server delle credenziali verifica la firma sul modulo di rilascio
    if openssl dgst -sha256 -verify ../user1/keys/keys_cie/public_key_u1_cie.pem -signature modulo_firmato.bin modulo.txt; then
        echo "Firma verificata con successo, generazione del Merkle Tree in corso..."
        echo "------------------------------------------"
        cd ..
        # Generazione del merkle tree
        bash ./gen_merkle_tree/gen_mt_u1.sh || { echo "Errore nella generazione del Merkle Tree."; exit 1; }
        # Verifica del merkle tree da parte dell'utente, inviato dal server 
        if ! bash ./verifica_merkle_tree.sh; then
            echo "Errore durante la verifica del Merkle Tree."
            cleanup
            exit 1
        fi
    else
        echo "Firma non verificata. Operazione abortita."
        exit 1
    fi
elif [[ $response == "n" ]]; then
    echo "Non verranno richieste le credenziali."
    exit 1
else
    echo "Risposta non valida. Si prega di rispondere con 'y' o 'n'."
    exit 1
fi
