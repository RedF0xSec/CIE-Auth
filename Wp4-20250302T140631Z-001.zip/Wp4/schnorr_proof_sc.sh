#!/bin/bash

# User1 dimostra di essere il possessore della chiave privata relativa alla chiave pubblica delle sue credenziali
echo "Invio della chiave pubblica al server delle credenziali..."
sleep 2

# Controlla se la chiave pubblica esiste prima di copiarla
if [ ! -f user1/keys/keys_user/public_key_u1_user.pem ]; then
    echo "Errore: Chiave pubblica non trovata!"
    exit 1
fi
cp user1/keys/keys_user/public_key_u1_user.pem server_Credenziali_Web || { echo "Errore nella copia della chiave pubblica!"; exit 1; }
echo "Chiave pubblica ricevuta!"
echo "------------------------------------------"

echo "Inizio protocollo di Schnorr..."
sleep 2

# Challenge che il server manda all'utente e l'utente la deve firmare 
echo "user1" > user1/test1.txt || { echo "Errore nella creazione del messaggio!"; exit 1; }
openssl dgst -sha256 -sign user1/keys/keys_user/private_key_u1_user.pem -out user1/signature1.bin user1/test1.txt || { echo "Errore nella firma del messaggio!"; exit 1; }

# Controlli per la copia dei file verso il server
cp user1/test1.txt server_Credenziali_Web && cp user1/signature1.bin server_Credenziali_Web || { echo "Errore nella copia del messaggio o della firma!"; exit 1; }

# Verifica della firma dal server delle credenziali
echo "serverWeb: verifico chiave user1..."
if openssl dgst -sha256 -verify server_Credenziali_Web/public_key_u1_user.pem -signature server_Credenziali_Web/signature1.bin server_Credenziali_Web/test1.txt; then
    echo "Verifica completata con successo. Protocollo di Schnorr terminato!"
else
    echo "Verifica fallita! Protocollo di Schnorr interrotto."
    exit 1
fi
echo "------------------------------------------"
